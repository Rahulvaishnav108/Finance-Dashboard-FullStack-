'use strict';

// Suppress the experimental warning for node:sqlite (stable in Node 22+, built-in)
process.removeAllListeners('warning');
process.on('warning', (w) => {
  if (w.name === 'ExperimentalWarning' && w.message.includes('SQLite')) return;
  process.stderr.write(`${w.name}: ${w.message}\n`);
});

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs   = require('fs');
const config = require('../config');

let _db = null;

function getDb() {
  if (_db) return _db;

  if (config.db.path !== ':memory:') {
    const dir = path.dirname(config.db.path);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }

  _db = new DatabaseSync(config.db.path);

  // Performance & integrity pragmas (node:sqlite uses exec, not .pragma())
  _db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA synchronous   = NORMAL;
    PRAGMA cache_size    = -64000;
    PRAGMA temp_store    = MEMORY;
  `);

  initSchema(_db);
  return _db;
}

/**
 * node:sqlite has no .transaction() helper.
 * This wraps a function in BEGIN / COMMIT / ROLLBACK.
 */
function makeTransaction(db, fn) {
  return (...args) => {
    db.exec('BEGIN');
    try {
      const result = fn(...args);
      db.exec('COMMIT');
      return result;
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  };
}

function initSchema(db) {
  db.exec(`
    -- ─────────────────────────────────────────
    -- USERS & AUTH
    -- ─────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS users (
      id            TEXT PRIMARY KEY,
      email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      full_name     TEXT NOT NULL,
      role          TEXT NOT NULL CHECK(role IN ('viewer','analyst','admin')),
      status        TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','suspended')),
      created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      last_login_at TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_users_role  ON users(role);

    -- ─────────────────────────────────────────
    -- REFRESH TOKENS
    -- ─────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS refresh_tokens (
      id         TEXT PRIMARY KEY,
      user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      revoked    INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      user_agent TEXT,
      ip_address TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_rt_user_id    ON refresh_tokens(user_id);
    CREATE INDEX IF NOT EXISTS idx_rt_token_hash ON refresh_tokens(token_hash);

    -- ─────────────────────────────────────────
    -- CATEGORIES
    -- ─────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS categories (
      id          TEXT PRIMARY KEY,
      name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
      type        TEXT NOT NULL CHECK(type IN ('income','expense','both')),
      color       TEXT,
      icon        TEXT,
      description TEXT,
      created_by  TEXT REFERENCES users(id) ON DELETE SET NULL,
      created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );

    -- ─────────────────────────────────────────
    -- FINANCIAL RECORDS
    -- ─────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS financial_records (
      id            TEXT PRIMARY KEY,
      amount        REAL NOT NULL CHECK(amount > 0),
      type          TEXT NOT NULL CHECK(type IN ('income','expense')),
      category_id   TEXT REFERENCES categories(id) ON DELETE SET NULL,
      date          TEXT NOT NULL,
      description   TEXT,
      notes         TEXT,
      tags          TEXT,
      reference_no  TEXT,
      status        TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','deleted')),
      created_by    TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
      updated_by    TEXT REFERENCES users(id) ON DELETE SET NULL,
      created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      deleted_at    TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_fr_type       ON financial_records(type);
    CREATE INDEX IF NOT EXISTS idx_fr_category   ON financial_records(category_id);
    CREATE INDEX IF NOT EXISTS idx_fr_date       ON financial_records(date);
    CREATE INDEX IF NOT EXISTS idx_fr_status     ON financial_records(status);
    CREATE INDEX IF NOT EXISTS idx_fr_created_by ON financial_records(created_by);
    CREATE INDEX IF NOT EXISTS idx_fr_date_type  ON financial_records(date, type);

    -- ─────────────────────────────────────────
    -- AUDIT LOG
    -- ─────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS audit_logs (
      id          TEXT PRIMARY KEY,
      user_id     TEXT REFERENCES users(id) ON DELETE SET NULL,
      action      TEXT NOT NULL,
      resource    TEXT NOT NULL,
      resource_id TEXT,
      old_data    TEXT,
      new_data    TEXT,
      ip_address  TEXT,
      user_agent  TEXT,
      created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );

    CREATE INDEX IF NOT EXISTS idx_audit_user_id    ON audit_logs(user_id);
    CREATE INDEX IF NOT EXISTS idx_audit_resource   ON audit_logs(resource, resource_id);
    CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_logs(created_at);
  `);
}

function closeDb() {
  if (_db) { _db.close(); _db = null; }
}

function resetDb() { closeDb(); }

module.exports = { getDb, closeDb, resetDb, makeTransaction };
